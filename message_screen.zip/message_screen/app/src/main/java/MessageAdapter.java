
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.message_screen.R;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.CustomViewHolder> {
    private ViewGroup parent;
    TextView textView;
    class CustomViewHolder extends RecyclerView.ViewHolder {

        public CustomViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textMessage);
        }
    }

    List<ResponseMessage> responseMessageList;
    public MessageAdapter(List<ResponseMessage> responseMessageList) {
        this.responseMessageList = responseMessageList;
    }
    @Override
    public int getItemViewType(int position) {
        if (responseMessageList.get(position).isMe())
        {
            return R.layout.me_bubble;
        }
        return R.layout.bot_bubble;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
       return new CustomViewHolder( LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false));

    }

    @Override
    public void onBindViewHolder( MessageAdapter.CustomViewHolder customViewHolder, int holder) {
         holder.textView.setText(responseMessageList.get(position).getTextMessage());
    }

    @Override
    public int getItemCount() {
        return responseMessageList.size();
    }
}
