package com.easyappointments.remote.ea.model.ws;

/**
 * Created by matte on 17/05/2017.
 */

public class ProviderSettingsModel extends BaseModel{
    public String username;
}
