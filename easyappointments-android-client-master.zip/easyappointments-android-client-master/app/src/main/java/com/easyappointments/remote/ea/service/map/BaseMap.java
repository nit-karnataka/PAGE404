package com.easyappointments.remote.ea.service.map;

import com.easyappointments.remote.ea.data.Options;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by matteo on 24/04/17.
 */

public abstract class BaseMap extends HashMap<Options, String> {
}
