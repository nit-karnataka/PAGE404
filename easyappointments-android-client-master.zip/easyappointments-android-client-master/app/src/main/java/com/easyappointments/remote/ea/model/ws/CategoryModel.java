package com.easyappointments.remote.ea.model.ws;

/**
 * Created by matte on 17/05/2017.
 */

public class CategoryModel extends BaseModel {
    public int id;
    public String name;
    public String description;
}
