package com.easyappointments.remote.ea.model.ws;

/**
 * Created by matteo on 24/04/17.
 */

public abstract class BaseModel {
}
