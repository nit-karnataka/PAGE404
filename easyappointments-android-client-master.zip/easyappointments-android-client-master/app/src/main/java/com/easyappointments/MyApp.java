package com.easyappointments;

import com.activeandroid.app.Application;

/**
 * Created by matte on 20/04/2017.
 */

public class MyApp extends com.activeandroid.app.Application {
}
