# How to contribute to the project

0 - Checkout repository <br>
1 - Go to projects tab (https://github.com/matteoventuri7/android-easyappointments/projects/1) <br>
2 - Choose one card from "To Do" column and write to me matteo.venturi7@gmail.com <br>
